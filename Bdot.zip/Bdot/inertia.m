%%%inertia and mass
m = 2.6; %%kilograms

%%%Inertia in kg-m^2
I = [0.9 0 0 ;0 0.9 0;0 0 0.3];
invI = inv(I);