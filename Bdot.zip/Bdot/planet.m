R = 6.371e6; %%meters
M = 5.972e24; %%kg
G = 6.67e-11;  %%%some SI unit
mu = G*M;