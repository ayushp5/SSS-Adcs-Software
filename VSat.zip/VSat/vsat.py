# from __future__ import division
# from visual import *
from physutil import *
# from visual.graph import *

import vpython as vp


vp.scene.title = "Satellite Motion"
vp.scene.background = vp.color.black

earth = vp.sphere(radius = 6.378e6, color = vp.color.blue)
satellite = vp.box(length=1e6, height=2e6, width=1e6, color=vp.color.green)

trail = vp.curve(color = vp.color.yellow, radius = 1e5) # units are in meters

print(vp)

vMotionMap = MotionMap(satellite, 100000, 10)
aMotionMap = MotionMap(satellite, 100000, 10)

earth.m = 5.972e24 # mass of the earth in kg
satellite.m = 1000 # mass of satellite in kg
satellite.pos = vp.vector(4.23e7, 0, 0) # initial position of the satellite, units are in meters
satellite.v = vp.vector(0, 3.07e3, 0) # initial velocity of the satellite

# Define time parameters
t = 0 # starting time
deltat = 36  # time step units are s

while t < 1200000 :
    # Required to make animation visible / refresh smoothly (keeps program from running faster
    #    than 1000 frames/s)
    vp.rate(1000)
    # computer the force of gravity on the satellite by the earth
    Fg = (6.673e-11) * satellite.m * earth.m / vp.mag(satellite.pos)**2
    # Compute Net Force
    Fnet = vp.vector(0, 0, 0) - satellite.pos # direction of the net force is toward the earth
    Fnet.mag = Fg # magnitude of the net force is the force of gravity
    # Newton's 2nd Law
    satellite.v = satellite.v + (Fnet/satellite.m * deltat)
    # Position update
    satellite.pos = satellite.pos + satellite.v * deltat
    # Update motion maps and trail
    trail.append(pos = satellite.pos)
    vMotionMap.update(t, satellite.v)
    aMotionMap.update(t, Fnet/satellite.m)
    # Time update
    t = t + deltat

print (t)
print (satellite.v)
print (Fnet/satellite.m)